print("Hello, world")
print("Setting up Code")
